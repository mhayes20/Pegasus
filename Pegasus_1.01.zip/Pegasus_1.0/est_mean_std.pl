use warnings;
use strict;

if(scalar(@ARGV) != 3)
{
	die("usage is perl est_mean_std.pl [BAM FILE] [MIN QUAL] [NUM PAIRS]\n");
}


my $input_file = $ARGV[0];
#my $sam_tools_path = $ARGV[3];

open(IN, "samtools view ".$input_file." |") or die ("Could not find input file!\n");


#Define variables for use in computing mean and standard deviation.
#Knuth's algorithm is used for the calculations.

my $temp_pointer;
my $line = "";
my $count = 0;
my $sum = 0;
my $mean = 0;
my $n = 0;
my $M2 = 0;
my $variance = 0;
my $variance_n = 0;
my $delta;
my $g = 0;
my $q = 0;
my @status = ();
my $num_pairs = $ARGV[2];
my $min_qual = $ARGV[1];
my @temp = ();
my $stdev = 0;


sub flagParse
{
        #Parse the SAM flag


        #FLAGS
        #1024 - PCR or optical duplicate
        #128 - 2nd read in pair
        #64 - 1st read in pair
        #32 - mate is reversed
        #16 - strand is reversed
        #8 - mate is unmapped
        #4 - read is unmapped
        #2 - reads are properly mapped
        #1 - read was paired in sequencing (this should always happen)
        my @vals = (1024, 128, 64, 32, 16, 8, 4, 2, 1);

        @status = (0, 0, 0, 0, 0, 0, 0, 0, 0);

        my $flag = $_[0];


        for(my $e = 0; $e < scalar(@vals); $e++)
        {
                if ($flag - $vals[$e] >= 0)
                {

                        $status[$e] = $vals[$e];
                        $flag -= $vals[$e];
                }

        }


}

my @left_right_pos = ();

print "est_mean_std.pl: Estimating mean and standard deviation...\n";
EAT_HEADER:
while($line = <IN>)
{

	
        chomp($line);
        @temp = split(/\t/, $line);

        if(substr($line, 0, 1) eq "@")
        {
                #Eat header
                goto EAT_HEADER;
        }

        flagParse($temp[1]);


        if($temp[4] >= $min_qual && $status[7] == 2 && $temp[8] > 0)
        {

                #Implementing Knuth's algorithm for finding mean and stdev in a single pass

                $n += 1;

                $delta = abs($temp[8]) - $mean;
                $mean = $mean + ($delta/$n);
                $M2 = $M2 + $delta * (abs($temp[8]) - $mean);

                $variance_n = $M2/$n;
                $count++;

        }
	
	if(eof(IN) && $count < $num_pairs)
	{
		print STDERR "WARNING: est_mean_std.pl: Number of valid paired alignments is less than the specified minimum!\n";
	}

        elsif($count >= $num_pairs || eof(IN))
        {
                last;

        }

}


$stdev = sqrt($variance_n);

print "mean: $mean      stdev:$stdev\n";

if(-e "$input_file.mean_std.txt")
{
	system("rm $input_file.mean_std.txt");
}

$mean = int($mean);
$stdev = int($stdev);
system("echo \"$mean\" >> $input_file.mean_std.txt");
system("echo \"$stdev\" >> $input_file.mean_std.txt");


close IN;
1;
