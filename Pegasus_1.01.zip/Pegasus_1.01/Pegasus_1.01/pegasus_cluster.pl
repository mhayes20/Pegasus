#!/usr/bin/perl


use warnings;
use strict;
use POSIX;

use List::Util qw(min max);


if(scalar(@ARGV) != 11 && scalar(@ARGV) != 13)
{
	die("Usage is: perl cluster_pq.pl [SAM_FILE] [STDEV constant] [MEAN (optional)] [STANDARD DEV. (optional)] [BREAKPOINT RESOLUTION?] [PATH TO INDEXED BAM] [PAIRS EST] [BLAT CONFIG] [MIN DEL] [MIN SC] [MAX SC] [MIN CLIP LEN] [MIN QUAL]]\n");


}

my $samtools_dir;
my $min_chimeric;
my $min_sc;
my $max_sc;
my $min_clip_len;
my $min_qual;
my $blat_config;

my $num_pairs;
my $bam_path;

my $blat_port;
my $blat_server;
my $blat_path;
my $blat_score;
my $blat_identity;
my @sc_i = ();
my @sc_j = ();


if(scalar(@ARGV) == 13)
{
	$bam_path = $ARGV[5];
	$num_pairs = $ARGV[6];
	$blat_config = $ARGV[7];
	$min_chimeric = $ARGV[8];
	$min_sc = $ARGV[9];
	$max_sc = $ARGV[10];
	$min_clip_len = $ARGV[11];
	$min_qual = $ARGV[12];
	
}
else
{
	$bam_path = $ARGV[3];
	$num_pairs = $ARGV[4];
	$blat_config = $ARGV[5];
        $min_chimeric = $ARGV[6];
        $min_sc = $ARGV[7];
        $max_sc = $ARGV[8];
        $min_clip_len = $ARGV[9];
        $min_qual = $ARGV[10];
}	


sub fetchBlatParams
{

	#Fetch the BLAT parameters that are in text file

	my @record = ();
	my $line = "";
	open(BL, "<$blat_config.blat_params.txt") or die("fetchBlatParams\nERROR: Cannot find the temporary BLAT parameter file!\n");

	$line = <BL>;
	chomp($line);
	$blat_port = $line;

	$line = <BL>;
        chomp($line);
        $blat_server = $line;
	
	$line = <BL>;
        chomp($line);
        $blat_path = $line;

	$line = <BL>;
        chomp($line);
        $blat_score = $line;
	
	$line = <BL>;
        chomp($line);
        $blat_identity = $line;
	
	close BL;	
			
}

sub mode
{
	my %hash = (); #Will store frequency of each element.
	my $e;
	my $mode = -1;	

	#build hash table. 
	foreach $e (@_)
	{
		$hash{$e} = 0;
	}

	for(my $i = 0; $i < scalar(@_); $i++)
	{
		#Count frequency of each element

		$hash{$_[$i]}++;

	}

	for $e (sort {$hash{$a} <=> $hash{$b}} keys %hash)
	{
		$mode = $e => $hash{$e}; #The last value assigned to "mode" will be the most frequently occuring element
	}
	return $mode;
}

sub contains
{
        my $i = 0;
        my $last = scalar(@_) - 1;
        for($i = 0; $i < scalar(@_) - 1; $i++)
        {
                if($_[$i] eq $_[$last])
                {
                        return 1;
		}
        }
        return 0;
}

my $bp_res;	#Apply breakpoint resolution? Should always be yes.

my $cur_chr; #Current chromosome being analyzed.
my $i_clip_count = 0; #Counts number of soft-clipped reads seen on opposite side of a potential variant.

sub chr_less
{

	#For the q-q and p-p cases, define total order on possible list of chromosomes. This functions checks if one chromosome is "less" than the other.
	#It is based on chromosome number. This is necessary because for the pp and qq cases, chri/chrj and chrj/chri fusions denote the same type of event.
	
        my @list = qw(chr1 chr2 chr3 chr4 chr5 chr6 chr7 chr8 chr9 chr10 chr11 chr12 chr13 chr14 chr15 chr16 chr17 chr18 chr19 chr20 chr21 chr22 chrX chrY);

        my $i = 0;

        for($i = 0; $i < @list; $i++)
        {
                if($_[0] eq $list[$i])
	        {
		         return 1;
                }
                elsif($_[1] eq $list[$i])
                {
                        return 0;
																					                }

	}

        return 0;
}



if(scalar(@ARGV) == 13)
{

	$bp_res = $ARGV[4];	#Apply breakpoint refinement procedure. Should always be set since the alternative option is deprecated.

	
}
elsif(scalar(@ARGV) == 11)
{
	$bp_res = $ARGV[2];
}



if($bp_res ne "Y" && $bp_res ne "N")
{
        die("cluster_pq.pl: Invalid choice for breakpoint resolution flag!\n");
}


fetchBlatParams();
my @bp_window = (); #NO LONGER USED. MARK FOR REMOVAL

my $clip_count = 0; #THIS VARIABLE STORES THE NUMBER OF SOFT CLIPPED READS SEEN SO FAR. 
my $read_length;
my $sub_read_length;
my $blat_line_file;
my $sub_read;
my $b_p = 0;

my @sub_read_locs_chrj = ();	#stores the set of locations that subreads map to on chr j
my @sub_read_locs_chri = ();	

my $i_blat_line_file = "";
my $k = $ARGV[1];
my $mean = 0;
my $stdev = 0;
my @temp = ();
my @status = ();

my @affect = (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24); #Stores list of chromosomes that will be analyzed.


sub flagParse
{
        #Parse the SAM flag


        #FLAGS
        #1024 - PCR or optical duplicate
	#128 - 2nd read in pair
        #64 - 1st read in pair
        #32 - mate is reversed
        #16 - strand is reversed
        #8 - mate is unmapped
        #4 - read is unmapped
        #2 - reads are properly mapped
        #1 - read was paired in sequencing (this should always happen)
        my @vals = (1024, 128, 64, 32, 16, 8, 4, 2, 1);

        @status = (0, 0, 0, 0, 0, 0, 0, 0, 0);

        my $flag = $_[0];

        
        for(my $e = 0; $e < scalar(@vals); $e++)
        {
                if ($flag - $vals[$e] >= 0)
                {

                        $status[$e] = $vals[$e];
			$flag -= $vals[$e];
                }

        }



}

if(scalar(@ARGV) == 13)	#Mean and stdev provided as parameters, so we don't need to estimate it. 
{
	$mean = $ARGV[2];
	$stdev = $ARGV[3];

	print "Mean is $mean\nStdev is $stdev\n";
	
	goto JUMP;
}



my $temp_pointer;
my $line = "";
my $count = 0;
my $sum = 0;
my $n = 0;
my $M2 = 0;
my $variance = 0;
my $variance_n = 0;
my $delta;
my $g = 0;
my $q = 0;

my @window_count = ();

my @left_right_pos = ();




JUMP:


open(IN, "<".$ARGV[0]) or die ("Could not find input file!\n");
open(OUT, ">".$ARGV[0].".out.del.csv") or die ("Could not write to output file!\n");


my $cur_pointer = 0;
my $cur_pos = 0;
my $upper_limit = 0;

$count = 1;

my $chr = "";

my $c = 1;
my $tag = "";
my $APcount = 0;	#Number of APs in cluster
my $cluster_start = 9999999999999999999999999;	#start position of the left read cluster. This is the left most of the left reads.
my $linked_cluster_start = 999999999999999999999999;	#start position of the linked cluster. This is the leftmost of the right reads of the linked cluster.
my $linked_chr = ""; #Chromosome on opposite side of variant
my @file_core = ();

my $tc = 0;
my $fc1 = 0;
my $fc2 = 0;

#foreach $c (@affect)
#{
	print "pegasus_cluster.pl: Searching for deletion clusters...\n";

	#print $ARGV[0]."\n";
	#$tag = $c;
#	if ($c == 23)
#	{
#		$tag = "X";
#	}
#	if ($c == 24)
#	{
#		$tag = "Y";
#	}
 

	EAT_HEADER2:	

	while($line = <IN>)
	{
		
	
	        chomp($line);
	        @temp = split(/\t/, $line);
	
		
		if(substr($temp[0],0,1) eq "@")
		{
			goto EAT_HEADER2;
		}
	
	
	        flagParse($temp[1]);
	
		if($temp[6] eq "="  && $temp[4] >= $min_qual && $status[3] == 32 && $status[4] == 0 && $status[0] == 0 && abs($temp[3] - $temp[7]) > ($k*$stdev + $mean) && abs($temp[8]) <= 100000000 && $temp[3] < $temp[7])
		{           
			$chr = $temp[6];
			
			$cur_chr = $temp[2];
			
			$linked_chr = $temp[6];			
			$cur_pointer = tell(IN);
			$cur_pos = $temp[3];			
			$upper_limit = $cur_pos + $mean + $k*$stdev;	
	
			$APcount++;	#We have first AP so we are incrementing the AP count
			$linked_cluster_start = $temp[7];
			$cluster_start = $temp[3];
			
			#PUSH THE ID AND  RIGHT READ POSITION OF THE FIRST PAIR ONTO THE STACK
			#THESE ARE THE POSITIONS OF THE READS THAT MAP TO THE OTHER SIDE OF THE DELETION
			
			push @left_right_pos, $temp[0], $temp[3], $temp[7];

			

			JUMP_BACK:
			while($cur_pos <= $upper_limit &&  !eof(IN))
			{
	
				#Get all discordant pairs
				my $temp_point = tell(IN);	
				$line = <IN>;
				chomp($line);
			        @temp = split(/\t/, $line);
				$cur_pos = $temp[3];
	
				if($temp[2] ne $cur_chr)
                                {
                                        #If the current chromosome is NOT the same as the read that started the window, then exit the while loop.
                                        
                                        $cur_pos = 9999999999999999999;                                     					
					seek(IN, $temp_point, 0);                                      					
                                        goto JUMP_BACK;
                                }
							
				flagParse($temp[1]);
				
				if ($temp[6] eq "="  && $temp[2] eq $cur_chr && $temp[4] >= $min_qual && $status[3] == 32  && $status[4] == 0 && $status[0] == 0 && abs($temp[3] - $temp[7]) > ($k*$stdev + $mean) && abs($temp[8]) <= 100000000 && $cur_pos <= $upper_limit && $temp[3] < $temp[7])
				{
					$APcount++;	#Finding subsequent overlapping APs, so incrementing the AP count
					$linked_chr = $temp[6];				

					push @left_right_pos, $temp[0], $temp[3], $temp[7];

				}
	
			}	
			
				
			#The following code handles the scenrario shown below. Due to error, the lowest read may have a mate that maps far away from the other mates in the cluster. It will then be filtered out.
			# >---------------------|------<
			#	>---------------|----------<		
			#   >-------------------|--------<			
			#  >--------------------|-------------------------------------<
			#		        |
			########################|######################################

			my $tempvar = (scalar(@left_right_pos))/3;
			my $v = 0;

		
			###window_count might be unused	
			for($v = 0; $v < $tempvar; $v++)
			{
				$window_count[$v] = 0;
			}	

			my @temp_max = ();
			my @max_cluster = ();

			for($g = 2; $g < scalar(@left_right_pos); $g += 3)
			{
				#g enumerates the windows

				my $tempg = ($g-2)/3;
				
				push @temp_max, $left_right_pos[$g-2], $left_right_pos[$g-1], $left_right_pos[$g];
				for($q = 2; $q < scalar(@left_right_pos); $q += 3)
				{
				
					if($g != $q && $left_right_pos[$q] >= ($left_right_pos[$g] - ($mean  + $k*$stdev)) && $left_right_pos[$q] <= $left_right_pos[$g])
					{
						#The pairs denoted by q are within the window
						#So increment the number of reads within the window

						$window_count[$tempg]++;
						push @temp_max, $left_right_pos[$q-2], $left_right_pos[$q-1], $left_right_pos[$q];
						#NOW PUSH THE ID OF THE READ AT Q ONTO ANOTHER STACK

					}



				}

					
				if(scalar(@max_cluster) < scalar(@temp_max))
				{
					@max_cluster = @temp_max;
				}
				@temp_max = ();


				#RECORD NUMBER OF READS IN THE WINDOW
			}
		
			@window_count = ();	
			@left_right_pos = ();

			my $b = 0;
			my $minb = 999999999999999;
			my $tempb = 0;

			my $temp_start = -99999999999999999;

			if(scalar(@max_cluster)/3 >= $min_chimeric) #Check number of chimeric read pairs in the cluster
			{					
			

				for($b = 1; $b < scalar(@max_cluster); $b += 3)
				{
					$tempb = $max_cluster[$b];
					if($tempb < $minb)
					{
						$minb = $tempb;
					}	
					if($tempb > $temp_start)
					{
						$temp_start = $tempb;
					}
				
				}

				$cluster_start = $minb;	#DEFINE beginning of chr i cluster. I'm just taking the min of all reads in the first cluster.

				my $temp_i_start = $temp_start;
				$minb = -99999999999999999; #NOTE: minb IS NOW BEING USED AS A MAX!!
				$temp_start = 99999999999999999;			   
				
				for($b = 2; $b < scalar(@max_cluster); $b += 3)
                                {
                                        $tempb = $max_cluster[$b];
                                        if($tempb > $minb)
                                        {
                                                $minb = $tempb;

                                        }
							
					if($tempb < $temp_start)
					{
						$temp_start = $tempb;

					}
				
                                }

				my $temp_j_start = $temp_start;
				$linked_cluster_start = $minb;
				$APcount = scalar(@max_cluster)/3;

				if($bp_res eq "N")
				{	
					print OUT "$count, ".$cur_chr.", ".$temp_i_start.", $APcount, ".$linked_chr.", ".$temp_j_start."\n"; 
				}
				else
				{
					 print OUT "$count, ".$cur_chr.", ".$temp_i_start.", $APcount, ".$linked_chr.", ".$temp_j_start; #DON'T ADD NEWLINE


				}

				
				#*********************BREAKPOINT RESOLUTION CODE HERE**********************

				$temp_pointer = tell(IN); #PROGRAM WILL JUMP BACK TO THIS POSITION WHEN BP RESOLUTION IS COMPLETE
							  #WHY AM I DOING THIS? I NEED TO RESTORE FILE POINTER TO THE POSITION IT HAD *AFTER*
							  #IT PERFORMED CLUSTERING. FOR BREAKPOINT RESOLUTION, THE PROGRAM MUST 'BACKTRACK' TO THE 
							  #FIRST CHIMERIC READ  IN CLUSTER.

				
				if($bp_res eq "Y")
				{

	
					seek(IN, $cur_pointer, 0); #SET FILE POSITION TO RECORD OF FIRST CHIMERIC PAIR
									#$cur_pointer was set earlier
					$line = <IN>;

	
					chomp($line);
					@temp = split(/\t/, $line);
			
					
					$upper_limit = $temp[3] + ($mean + $k*$stdev); #DEFINE SIZE OF WINDOW
					$cur_pos = $temp[3];
					@sub_read_locs_chri = ();
					@sub_read_locs_chrj = ();
					
				

					$clip_count = 0;
			 		while($cur_chr eq $temp[2] && $cur_pos <= $upper_limit && !eof(IN)) 	#GET THE CHIMERIC READ THAT FIRST DEFINED THE CLUSTER. THE WINDOW WILL FORM FROM HERE.
					{		#NOTE THAT I AM USING A SINGLE WINDOW EXTENDED FROM THE FIRST CHIMERIC READ.
							#IT MAKES IT SIMPLER.
					
						
						if($temp[5] =~ /([0-9]+[A-Z]+)([0-9]+)(S)/)  #IF CIGAR STRING SAYS CURRENT READ IS SOFTCLIPPED
						{ 								#AND IF LESS THAN 5 CLIPPED READS WERE PROCESSED.

							#print "SOFT-CLIPPED READ ID: ".$temp[0]."\n";
							
							$read_length = length($temp[9]); #GET LENGTH OF CURRENT READ
							$sub_read = substr $temp[9], ($read_length - $2); #GET CLIPPED SUB READ
					
							#IF READ WAS REVERSED, THEN CLIPPED SUBREAD MUST BE COMPLEMENTED
							flagParse($temp[1]);

					
							$sub_read_length = length($sub_read);

							if($sub_read_length >= $min_clip_len) #SUBREAD IS SUFFICIENTLY LONG ENOUGH TO RUN BLAT
							{
							
								open(QUERY, ">$bam_path.query.tmp.del.txt") or die ("ERROR: pegasus_cluster.pl: Could not create the temporary query file!\n");
								print QUERY ">query\n$sub_read"; #CREATE THE FILE THAT WILL BE USED AS QUERY
								close QUERY;			 #TO BLAT.
								
								
								#print "pegasus_cluster.pl: Found soft-clipped read: blatting...\n";
							
	 							my $r = 0;
								$r = system("$blat_path/gfClient $blat_server $blat_port \"\" $bam_path.query.tmp.del.txt $bam_path.output.tmp.del.txt -minScore=$blat_score -minIdentity=$blat_identity > /dev/null"); 
								open(BLAT_IN, "<$bam_path.output.tmp.del.txt") or die ("ERROR: cluster_pq.pl Could not open BLAT output file! $bam_path.output.tmp.del.txt\n");
								$blat_line_file = <BLAT_IN>;	##EAT THE BLAT FILE HEADER
								$blat_line_file = <BLAT_IN>;
								$blat_line_file = <BLAT_IN>;								
								$blat_line_file = <BLAT_IN>;
								$blat_line_file = <BLAT_IN>;

								while($blat_line_file = <BLAT_IN>)
								{	
									#SEARCH FOR VALID ALIGNMENT RESULTS IN BLAT OUTPUT
									my @blat_temp = ();
									chomp($blat_line_file);

									@blat_temp = split(/\t/, $blat_line_file);

									if($blat_temp[8] eq "+" && $blat_temp[13] eq $cur_chr && $blat_temp[15] <= $linked_cluster_start && $blat_temp[15] >= $linked_cluster_start - ($mean+$k*$stdev)) #IF ALIGNMENT IS TO CORRECT CHROMOSOME AND IN RANGE
									{
										#				print "LOCATION FOUND: ".$blat_temp[15]."\n";
										$clip_count++;
										push @sub_read_locs_chrj, $blat_temp[15]; #PUSH LOCATION OF VALID SUBREAD ALIGNMENT ON CHR J
										push @sc_j, $blat_temp[15];
										push @sub_read_locs_chri, $cur_pos + length(substr($temp[9],0,($read_length - length($sub_read))))-1; #DO THE SAME FOR CHR I
		#WE ARE SUBTRACTING 1 BECAUSE THE CLIPPED COUNT
		#IS INCLUSIVE TO THE FIRST BASE IN ALIGNMENT
		#

										my $bp_temp = $cur_pos + length(substr($temp[9],0,($read_length - length($sub_read))))-1;
										
										if($clip_count >= $max_sc)
										{

											$clip_count = 0;
											goto CLOSE_BLAT;
								

										}
										


									}

									

								}


							}				
							else
							{
								#CLIPPED SUBREAD WASN'T LONG ENOUGH.
								#FETCH THE NEXT RECORD.
								goto GET_RECORD;

							}
														

						#NOTE: $sub_read NOW CONTAINS THE SUBREAD THAT WILL BE QUERIED TO BLAT	
						
						#$2 is a REGULAR EXPRESSION VARIABLE USED TO EXTRACT MATCHES.
						#THIS MEANS THAT THE LAST CHARACTER IS AN 'S', SO THE READ IS SOFT 
						#CLIPPED.

						}

						GET_RECORD:
						$line = <IN>;				#FETCH NEXT RECORD
						chomp($line);
			                        @temp = split(/\t/, $line);					
					
						$cur_pos = $temp[3];		
		
						
						


					}
			CLOSE_BLAT:
					close BLAT_IN; #CLOSE THE BLAT OUTPUT FILE. WE ARE DONE WITH IT.
					$clip_count = 0; # RESET CLIP COUNT FOR THE NEXT CLUSTER



					$i_clip_count = 0;
					
					#In the following code, we are now performing breakpoint refinement from the chromosome j side

					#if($c == 23)
					#{
					#	system("samtools view $bam_path chrX:".floor(0.5 + $linked_cluster_start - ($mean+$k*$stdev))."-$linked_cluster_start"." > $bam_path.linked_j.del.txt");
					#}
					#elsif($c == 24)
					#{
					#	system("samtools view $bam_path chrY:".floor(0.5 + $linked_cluster_start - ($mean+$k*$stdev))."-$linked_cluster_start"." > $bam_path.linked_j.del.txt");
					#}
					#else
					#{
					#	system("samtools view $bam_path chr$c:".floor(0.5 + $linked_cluster_start - ($mean+$k*$stdev))."-$linked_cluster_start"." > $bam_path.linked_j.del.txt");
					#}

					system("samtools view $bam_path $cur_chr:".floor(0.5 + ($temp_j_start - ($mean+$k*$stdev)))."-$temp_j_start"." > $bam_path.linked_j.DEL.txt");

					my $file_flag = 0;
	
					my $i_line = "";	
					my @i_record = ();
		
					open(SAM_J_REGION, "<$bam_path.linked_j.DEL.txt") or die ("Could not find the temporary alignment file for the linked chromosome $c!\n");
					while($i_line = <SAM_J_REGION>)
					{

						chomp($i_line);
						@i_record = split(/\t/, $i_line);
						if($i_record[5] =~/([0-9]+)(S)([0-9]+[A-Z]+)/)
						{ #Opposite soft-clipped read found
							#ATTEMPT REMAPPING OF THE CLIPPED PORTION
								
							my $i_sub_read = substr $i_record[9], 0, $1; #GOT CLIPPED POSITION
							my $i_sub_read_length = length($i_sub_read);
					
					
						        if($i_sub_read_length >= $min_clip_len) #SUBREAD IS SUFFICIENTLY LONG ENOUGH TO RUN BLAT
                                                        {

                                                                 open(I_QUERY, ">$bam_path.query.i.del.txt") or die ("Could not create the temporary i_query file!\n");
                                                                 print I_QUERY ">query\n$i_sub_read"; #CREATE THE FILE THAT WILL BE USED AS QUERY
                                                                 close I_QUERY;     

		
								 #print "pegasus.pl: Found soft-clipped read on opposite side of breakpoint: blatting...\n";

								system("$blat_path/gfClient $blat_server $blat_port \"\" $bam_path.query.i.del.txt $bam_path.output.i.del.txt -minScore=$blat_score -minIdentity=$blat_identity > /dev/null");

						   	        		
								open(I_BLAT_IN, "$bam_path.output.i.del.txt") or die ("pegasus_cluster.pl: could not open I_BLAT output file!\n");
	                                                        $i_blat_line_file = <I_BLAT_IN>;    ##EAT THE FILE HEADER
	                                                        $i_blat_line_file = <I_BLAT_IN>;
	                                                        $i_blat_line_file = <I_BLAT_IN>;
	                                                        $i_blat_line_file = <I_BLAT_IN>;
	                                                        $i_blat_line_file = <I_BLAT_IN>;
	
	
								while($i_blat_line_file = <I_BLAT_IN>)
	                                                        {
	                                                        	#SEARCH FOR VALID ALIGNMENT RESULTS
	                                                        	my @i_blat_temp = ();
	                                                        	chomp($i_blat_line_file);
	
	                                                         	@i_blat_temp = split(/\t/, $i_blat_line_file);
									#print "GOT LINE FROM LINKED LOC\n";	
										
	        		                	                 if($i_blat_temp[8] eq "+" && $i_blat_temp[13] eq $cur_chr && $i_blat_temp[16] >= $cluster_start && $i_blat_temp[16] <= $cluster_start+($mean+$k*$stdev))
									 { 	
										
										 # print "LINKED FOUND AT".$i_blat_temp[16]."\n";

										 $i_clip_count++;							
										 push @sub_read_locs_chri, $i_blat_temp[16]; #PUSH LOCATION OF VALID SUBREAD ALIGNMENT ON CHR J
					
										 push @sc_i, $i_blat_temp[16];
		                                                                 push @sub_read_locs_chrj, $i_record[3]; 
										 if($i_clip_count >= $max_sc)
									 	 { 
											$i_clip_count = 0;
											goto CLOSE_I_BLAT;

										 }
		
									  }
		
								 }
								close I_BLAT_IN;
							}
				
						}	
					}
		
				CLOSE_I_BLAT:
				close I_BLAT_IN;
				
				#####**********************************************************************************************************

					if($cur_chr eq "chr23")
					{
						$cur_chr = "chrX";
					}
					elsif($cur_chr eq "chr24")
					{
						$cur_chr = "chrY";
					}

					print OUT ", ".$cur_chr.", ";

					
								
					if(scalar(@sc_i) >= $min_sc && scalar(@sc_j) >= $min_sc)
					{

						#At least min_sc soft-clipped reads must support breakpoint to call the prediction
						print OUT mode(@sub_read_locs_chri);  
				
					}

					print OUT ", $cur_chr".", ";

					if(scalar(@sc_i) >= $min_sc && scalar(@sc_j) >= $min_sc)
                                        {
						print OUT mode(@sub_read_locs_chrj); 
					}

					print OUT ", +, +";
					print OUT ", ".scalar(@sc_i).", ".scalar(@sc_j)."\n";
					@bp_window = ();
			
					@sc_i = ();
					@sc_j = ();	
					#print "Contents of sub_read_locs_chrj: @sub_read_locs_chrj\n";
                                        #print "Min of sub_read_locs_chrj: ".min(@sub_read_locs_chrj)."\n";
					for($b_p = 0; $b_p < $mean + $k*$stdev; $b_p++)
					{
					        push @bp_window, 0;

					}	

				}
				seek(IN, $temp_pointer, 0);
			
			}
	
			$count++;
			$APcount = 0;
	
		}	

	}
	
	


#}			

close OUT;
close IN;
1;
