our $blat_port;
our $blat_server;
our $blat_path;
our $minScore;
our $minIdentity;
our $blat_config;

sub checkBlatParams
{
	my $line;
	my @record = ();
	my %blat_params;


	$blat_params{"blat_port"} = -1;
        $blat_params{"blat_server"} = -1;
        $blat_params{"blat_path"} = -1;
        $blat_params{"minScore"} = -1;
        $blat_params{"minIdentity"} = -1;

	if(!(-e "$blat_config"))
	{
		print "WARNING: BLAT config file not found in local directory! Using default parameters...\n";
		goto DEFAULTS;
	}
	else
	{
		open(IN, "<$blat_config") or die("ERROR: BLAT config unexpectedly missing!\n");
	}

	while($line = <IN>)
	{

		chomp($line);
		@record = split(/=/, $line);	
		
		$blat_params{$record[0]} = $record[1];

	}
	

	DEFAULTS:
	if($blat_params{"blat_port"} == -1 || $blat_params{"blat_port"} =~ /^\s*$/)
	{
		print "WARNING: blat_port not specified in $blat_config! Using default port 8000.\n";
		$blat_params{"blat_port"} = 8000;
	}
	if($blat_params{"blat_server"} == -1 || $blat_params{"blat_server"} =~ /^\s*$/)
        {
                print "WARNING: blat_server not specified in $blat_config! Using default server localhost.\n";
		$blat_params{"blat_server"} = "localhost";
        }
	if($blat_params{"blat_path"} == -1 || $blat_params{"blat_path"} =~ /^\s*$/)
        {
                print "WARNING: blat_path not specified in $blat_config! Using default current directory.\n";
                $blat_params{"blat_path"} = "./";
        }	
	
	if($blat_params{"minScore"} == -1 || $blat_params{"minScore"} =~ /^\s*$/)
        {
                print "minScore not specified. Using default value of 20.\n";
                $blat_params{"minScore"} = 20;
        }
	if($blat_params{"minIdentity"} == -1 || $blat_params{"minIdentity"} =~ /^\s*$/)
        {
                print "minIdentity not specified. Using default value of 90.\n";
                $blat_params{"minIdentity"} = 90;
        }
		
	$blat_port = $blat_params{"blat_port"};
	$blat_server = $blat_params{"blat_server"};
	$blat_path = $blat_params{"blat_path"};
	$minScore = $blat_params{"minScore"};
	$minIdentity = $blat_params{"minIdentity"};

	close IN;

}
checkBlatParams();

open(OUT, ">$blat_config.blat_params.txt") or die ("ERROR: check_blat_config.pl: Could not write BLAT parameters to file!\n");

print OUT "$blat_port\n";
print OUT "$blat_server\n";
print OUT "$blat_path\n";
print OUT "$minScore\n";
print OUT "$minIdentity\n";
close OUT;
1;
