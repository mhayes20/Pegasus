#!/usr/bin/perl

use warnings;
use strict;
no warnings 'uninitialized';


#preprocess.pl
#Extracts discordant read pairs and soft-clipped reads to a SAM file.
#All soft-clipped reads are extracted. Only read pairs with specified alternative quality are kept.
#NOTE:  Use of this tool is recommended if the BAM file is not already filtered by discordant pairs and soft-clipped reads.

#####	NOTE: This program will dump the chimeric pairs and soft-clipped alignments to a SAM file!! ###############



if(scalar(@ARGV != 3))
{
	die("usage is perl preprocess.pl [PATH TO INDEXED BAM FILE] [ALT QUAL] [WINDOW]\n");
}


my @temp_record = ();
my $index_file_name = $ARGV[0].".bai";
my $alt_qual = $ARGV[1];
my $window = $ARGV[2];
my %c_hash = ();

open(IN, "samtools view ".$ARGV[0]." |") or die ("Could not find input file!\n");
open(OUT, ">".$ARGV[0].".stripped.sam") or die ("Could not open stripped sam file for writing!\n");

unless (-e $index_file_name)
{

	close IN;
	close OUT;
	die("preprocess.pl\nERROR: index file not found for the BAM file specified!\n");


}

my $line = "";
my $temp_line = "";
my @record = ();
my $mate_chr = "";
my $mate_pos = 0;
my $mate_score = 0;
my $displayFlag = 1;
my $count = 0;


print "preprocess.pl: Building discordant read pair hash table...\n";
while($line = <IN>)	
{
	
	
	$count++;
	chomp($line);
	
	@record = split(/\t/, $line);

	#IF DISCORDANT, ADD ID_chr, alignment score pair to hash
	
	#print "record[4]: ".$record[4]."\n";
	
	
	if(substr($record[0], length($record[0])-2, 2) eq "\\2" or substr($record[0], length($record[0])-2, 2) eq "\\1")
        {
                        $record[0] = substr($record[0], 0, (length($record[0])-2))
        }
	if($record[6] eq "=" && abs($record[8]) > $window && $record[8] > 0)
	{
		$c_hash{ $record[0]."_____".1 } = $record[4]; #There are 5 underscores
		
	}
	if($record[6] eq "=" && abs($record[8]) > $window && $record[8] < 0)
	{
	      	$c_hash{ $record[0]."_____".2 } = $record[4]; #There are 5 underscores

        }
	
	

}
print "done.\n";
$count = 0;
close IN;

open(IN, "samtools view -h ".$ARGV[0]." |") or die ("Could not find input file!\n");
	
print "preprocess.pl: Extracting discordant pairs and soft-clipped reads...";
EAT_HEADER:
while($line = <IN>)
{
	

	if(substr($line, 0, 1) eq "@")
        {
		#Eat the header.
	        print OUT $line;
        	goto EAT_HEADER;
        }


	;
	$count++;
	
	chomp($line);

	@record = split(/\t/, $line);

	WRITE_RECORD:	

	if(($record[5] =~ /([0-9]+[A-Z]+)([0-9]+)(S)/) || ($record[5] =~ /([0-9]+)(S)([0-9]+[A-Z]+)/))
	{
		#KEEP ALL SOFT-CLIPPED READS REGARDLESS OF SCORE

		
		print OUT "$line\n";
	


	}
	elsif($record[6] eq "=" && abs($record[8]) > $window)
        {
                #ONLY KEEP A DISCORDANT RECORD IF IT'S SCORE AND ITS MATE'S SCORE ARE HIGH ENOUGH.S


		if(substr($record[0], length($record[0])-2, 2) eq "\\2" or substr($record[0], length($record[0])-2, 2) eq "\\1")
	        {
			$record[0] = substr($record[0], 0, (length($record[0])-2))
	        }

		if($c_hash{$record[0]."_____".1} ne undef || $c_hash{$record[0]."_____".2} ne undef)
		{
			
			if($record[8] > 0)
			{
				$mate_score = $c_hash{$record[0]."_____".2};
			}
			if($record[8] < 0)
			{
				$mate_score = $c_hash{$record[0]."_____".1};
			}
	

        	        if($record[4] >= $alt_qual && $mate_score >= $alt_qual)
        	        {
                	        print OUT "$line\n";
	                }	

		}
        }



}
print "done.\n";

close IN;
close OUT;
1;
