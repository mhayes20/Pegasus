#!/usr/bin/perl

use warnings;
use strict;

use Getopt::Long;

######Set default parameter values
my $min_del = 4;
my $min_soft_clipped = 3;
my $max_soft_clipped = 20;
my $min_quality = 30;
my $no_estimate_mean_std = 0;
my $max_dup_del_length = 1000000;
my $min_soft_clipped_length = 20;
my $num_pairs_est = 10000;
my $std_cutoff = 4;
my $mean_pairs = 400;
my $std_pairs = 80;
my $skip_pre = 0;
my $p = 0; #Used for a future released of Bellerophon. DO NOT ALTER.
####################################

######BLAT config parameters####
our $blat_port;
our $blat_server;
our $blat_path;
our $minScore;
our $minIdentity;
###############################

my $input_bam_file;
my $samtools_directory = ""; #Not used anymore. User must specify samtools in the PATH.
our $blat_config;

my $main_sam_file;
my $window_size; #Size of window to send the classifier

sub outputFiles
{
	#Prints the location of the program result files

	print "\nOutput is in:\n\t$input_bam_file.breakpoints.txt\n";
	
}
sub mergeOutputFiles
{
	


	if(-e "$main_sam_file.combined.txt")
	{
		system("rm $main_sam_file.combined.txt");
	}
	
	
	
	system("cat $main_sam_file.out.del.csv >> $main_sam_file.combined.txt");
	

	system("grep -v \", -1,\" $main_sam_file.combined.txt | grep -v \", ,\" > $main_sam_file.combined.precise.txt"); #Remove records that have no precise breakpoint predictions

}

sub parseOutput
{
	#Parses the classification results and puts them in a nicer looking format
	#There will be 5 output files (if classification is selected)
		#File with pure breakpoints
		#Unbalanced translocation predictions
		#Balanced translocation predictions
		#Interchromosomal insertion predictions
		#Breakpoints that could not be classified		

	#First reformat the breakpoint file

	my $line = "";
	my @record = ();

	my $chri = "";	
	my $chrj = "";
	my $pos_i = "";
	my $pos_j = "";
	my $strand1 = "";
	my $strand2 = "";
	my $AP = "";	#Abnormal or discordant pairs
	my $chr1_sc = 0;
	my $chr2_sc = 0;
 

	my $deletions = "$main_sam_file.combined.txt.balanced.txt";
	#my $unbalanced = "$main_sam_file.combined.txt.unbalanced.txt";
	#my $insertion = "$main_sam_file.combined.txt.insertions.txt";
	#my $unclassified = "$main_sam_file.combined.txt.unclassified.txt";
	open(IN, "<$main_sam_file.combined.precise.txt") or die("ERROR: pegasus.pl: Could not open combined cluster output file!\n");
	open(OUT, ">$input_bam_file.breakpoints.txt") or die("ERROR: pegasus.pl: Could not write to the breakpoint predictions file!\n");
		

	print OUT "chr1\tpos1\tchr2\tpos2\tstrand1\tstrand2\tnum_discordant\tSC1\tSC2\n\n";
	
	while($line = <IN>)
	{
		while($line eq "\n") {$line = <IN>;}
		chomp($line);
		@record = split(/, /, $line);		
		$chri = $record[1];
		$pos_i = $record[7];
		$pos_j = $record[9];
		$AP = $record[3];
		$chrj = $record[4]; 
		$strand1 = $record[10];
		$strand2 = $record[11];
		$chr1_sc = $record[12];
		$chr2_sc = $record[13];				
							
		
		print OUT "$chri\t$pos_i\t$chrj\t$pos_j\t$strand1\t$strand2\t$AP\t$chr1_sc\t$chr2_sc\n";
	
		
	}
	close IN;
	close OUT;
}

sub cleanup
{
	#Remove all temporary/intermediate files used in the pipeline

	
	if(-e "$main_sam_file.mean_std.txt")
	{
		system("rm $main_sam_file.mean_std.txt");
	}
	
	if(-e $main_sam_file)
	{	
		system("rm $main_sam_file");
	}
	if(-e "$main_sam_file.combined.txt")
	{
		system("rm $main_sam_file.combined.txt");
	}
	if(-e "$main_sam_file.combined.precise.txt")
        {
                system("rm $main_sam_file.combined.precise.txt");
        }
	if(-e "$main_sam_file.combined.txt.unclassified.txt")
	{
		system("rm $main_sam_file.combined.txt.unclassified.txt");
	}
	if(-e "$main_sam_file.combined.txt.unbalanced.txt")
	{
		system("rm $main_sam_file.combined.txt.unbalanced.txt");
	}
	if(-e "$main_sam_file.combined.txt.balanced.txt")
	{	
		system("rm $main_sam_file.combined.txt.balanced.txt");
	}
	if(-e "$main_sam_file.combined.txt.insertions.txt")
	{
		system("rm $main_sam_file.combined.txt.insertions.txt");
	}
	if(-e "$input_bam_file.query.i.plus.plus.txt")
	{
		system("rm $input_bam_file.query.i.plus.plus.txt");
	}
	if(-e "$input_bam_file.query.i.plus.minus.txt")
	{	
		system("rm $input_bam_file.query.i.plus.minus.txt");
	}
	if(-e "$input_bam_file.query.i.minus.plus.txt")
	{
		system("rm $input_bam_file.query.i.minus.plus.txt");
	}
	if(-e "$input_bam_file.query.tmp.plus.minus.txt")
	{
		system("rm $input_bam_file.query.tmp.plus.minus.txt");
	}
	if(-e "$input_bam_file.query.tmp.plus.minus.txt")
	{
	        system("rm $input_bam_file.query.tmp.plus.minus.txt");
	}
        if(-e "$input_bam_file.query.tmp.minus.plus.txt")
	{
		system("rm $input_bam_file.query.tmp.minus.plus.txt");
	}
	if(-e "$input_bam_file.query.tmp.plus.plus.txt")
	{
		system("rm $input_bam_file.query.tmp.plus.plus.txt");
	}
	if(-e "$input_bam_file.output.tmp.plus.plus.txt")
	{
		system("rm $input_bam_file.output.tmp.plus.plus.txt");
	}
	if(-e "$input_bam_file.output.tmp.plus.plus.txt")
	{
		system("rm $input_bam_file.output.tmp.plus.plus.txt");
	}
	if(-e "$input_bam_file.output.tmp.plus.minus.txt")
	{
		system("rm $input_bam_file.output.tmp.plus.minus.txt");
	}
	if(-e "$input_bam_file.output.tmp.minus.plus.txt")
	{
		system("rm $input_bam_file.output.tmp.minus.plus.txt");
	}
	if(-e "$input_bam_file.output.i.plus.plus.txt")
	{
		system("rm $input_bam_file.output.i.plus.plus.txt");
	}
	if(-e "$input_bam_file.output.i.plus.minus.txt")
	{
		system("rm $input_bam_file.output.i.plus.minus.txt");
	}
	if(-e "$input_bam_file.output.i.minus.plus.txt")
	{
		system("rm $input_bam_file.output.i.minus.plus.txt");
	}
	if(-e "$input_bam_file.linked_j.plus.plus.txt")
	{
		system("rm $input_bam_file.linked_j.plus.plus.txt");
	}
	if(-e "$input_bam_file.linked_j.plus.minus.txt")
	{
		system("rm $input_bam_file.linked_j.plus.minus.txt");
	}
	if(-e "$input_bam_file.linked_j.minus.plus.txt")
	{
		system("rm $input_bam_file.linked_j.minus.plus.txt");
	}
	if(-e "blat_params.txt")
	{
		system("rm blat_params.txt");
	}
	if(-e "$main_sam_file.REVERSE.sam")
	{
		system("rm $main_sam_file.REVERSE.sam");	
	}
	if(-e "$main_sam_file.out.minus.plus.csv")
	{
		system("rm $main_sam_file.out.minus.plus.csv");
	}
	if(-e "$main_sam_file.out.plus.plus.csv")
        {
                system("rm $main_sam_file.out.plus.plus.csv");
        }
	if(-e "$main_sam_file.out.plus.minus.csv")
        {
                system("rm $main_sam_file.out.plus.minus.csv");
        }
	if(-e "$blat_config.blat_params.txt")
	{
		system("rm $blat_config.blat_params.txt");
	}

}

sub Usage
{
	my $message = $_[0];
	die($message);	
}

sub options
{
	print "\nPegasus v1.0";

	print "\n\nperl pegasus.pl --input_bam {indexed and sorted bam file} --blat_config {path to Blat config file} [OPTIONS]\n
OPTIONS\n
	--min_del				Minimum number of abnormally long forward-reverse read pairs in a cluster [4]
	--min_soft_clipped			Minimum total soft-clipped reads from either side to predict precise breakpoints [3]
	--max_soft_clipped			Cease breakpoint refinement procedure if number of processed soft-clipped reads exceeds this number [20]
	--min_score				Minimum alternative mapping quality of chimeric read pairs (if preprocessing is skipped, then this is a threshold for individual read mapping quality) [30]
	--min_clip_len				Minimum length of a soft-clipped read to trigger breakpoint refinement (NOTE: it is NOT recommended to choose a value less than 20) [20]
	--ne					Do NOT estimate mean and standard deviation from data [unset]
	--mean_pairs				Mean insert length (bp) of read pairs (only used if --ne is set) [400]
	--std_pairs				Standard deviation of insert lengths of read pairs (only used if --ne is set) [80]	
	--num_pairs				Number of pairs to estimate mean and standard deviation [10000]
	--k					Standard deviation cutoff for determining discordant read pairs [4]
	--skip_pre				Skip preprocess step (NOT recommended if BAM file is not filtered by 1) chimeric pairs with alt quality >= some threshold and 2) soft clipped reads) [do not skip]\n\n";
	
}


my $r = `samtools >& does_samtools_exist.txt; echo \$?`;

if($r == 127)
{
	system("rm does_samtools_exist.txt");
	die("ERROR: pegasus.pl: Samtools not found. Is it in your PATH variable?\n");
}
system("rm does_samtools_exist.txt");


GetOptions ('input_bam=s' => \$input_bam_file,
	    'blat_config=s' => \$blat_config,
	    'min_del=i' => \$min_del,
	    'min_soft_clipped=i' => \$min_soft_clipped,
	    'max_soft_clipped=i' => \$max_soft_clipped,
	    'min_score=i' => \$min_quality,
	    'min_clip_len=i' => \$min_soft_clipped_length,
	    'mean_pairs=f' => \$mean_pairs,
	    'std_pairs=f' => \$std_pairs,
	    'ne' => \$no_estimate_mean_std,
	    'num_pairs=i' => \$num_pairs_est,
	    'k=i' => \$std_cutoff,
	    'skip_pre' => \$skip_pre) or Usage("Invalid commmand line options.\n");

unless(defined $input_bam_file) { options(); Usage("Please provide the path to an indexed BAM file!\n"); }
#Usage("Please provide the path to an indexed BAM file!\n") unless defined $input_bam_file;

unless (-e $input_bam_file) { options(); Usage("Specified BAM file does not exist!\n"); }
unless (-e $input_bam_file.".bai") { options(); Usage("Index file for input BAM not found!\n"); }


my %options = ();
require("check_blat_config.pl");




#RUN CLUSTERING PROGRAMS
if($no_estimate_mean_std == 0)
{
                #Estimate mean and stdev from data

		
		system("perl est_mean_std.pl $input_bam_file $min_quality $num_pairs_est $samtools_directory");
		open(EST, "<".$input_bam_file.".mean_std.txt") or die("ERROR: pegasus.pl: could not open the mean/stdev file!\n");
	
		$mean_pairs = <EST>;
		chomp($mean_pairs);
		$std_pairs =  <EST>;
		chomp($std_pairs);
		
		$window_size = $mean_pairs + $std_pairs*$std_cutoff;
	
		close EST;

		print "Mean: $mean_pairs\nStandard deviation: $std_pairs\n";

			
		if($skip_pre == 0)
		{
			#my $w = $std_cutoff*$stdev + $mean; 
			system("perl preprocess.pl $input_bam_file $min_quality $window_size");
			$main_sam_file = $input_bam_file.".stripped.sam";

		}
		else
		{
	
			if(-e $input_bam_file.".stripped.sam")
			{
				print "pegasus.pl: $input_bam_file.stripped.sam exists! Will not be overwritten.\n";
				$main_sam_file = $input_bam_file.".stripped.sam";
			}
			else 
			{
				print "pegasus.pl: converting BAM file to SAM...\n";
				system("samtools view $input_bam_file > $input_bam_file.sam");
				$main_sam_file = $input_bam_file.".sam";
			}

		}
		if($p == 0) #Don't run clustering in parallel. #For now, this is condition is always true.
		{
	
			
			system("perl pegasus_cluster.pl $main_sam_file $std_cutoff $mean_pairs $std_pairs Y $input_bam_file $num_pairs_est $blat_config $min_del $min_soft_clipped $max_soft_clipped $min_soft_clipped_length $min_quality");
			
			#Merge output files 
			mergeOutputFiles();	
		

			parseOutput();
		}
               

}
else
{
	#Mean and stdev provided by user

	
	print "Mean: $mean_pairs\nStandard deviation: $std_pairs\n";
		
	$window_size = $mean_pairs + $std_pairs*$std_cutoff;
	
	if($skip_pre == 0)
	{
		#my $w = $std_cutoff*$stdev + $mean; 
		system("perl preprocess.pl $input_bam_file $min_quality $window_size");
		$main_sam_file = $input_bam_file.".stripped.sam";

	}
	else
	{	
	
		if(-e $input_bam_file.".stripped.sam")
		{
			print "pegasus.pl: $input_bam_file.stripped.sam exists! Will not be overwritten.\n";
			$main_sam_file = $input_bam_file.".stripped.sam";
		}
		else 
		{
			print "pegasus.pl: converting BAM file to SAM...\n";
			system("samtools view $input_bam_file > $input_bam_file.sam");
			$main_sam_file = $input_bam_file.".sam";
		}

	}

	if($p == 0) #For now, this condition is always true.
	{
			
		system("perl pegasus_cluster.pl $main_sam_file $std_cutoff $mean_pairs $std_pairs Y $input_bam_file $num_pairs_est $blat_config $min_del $min_soft_clipped $max_soft_clipped $min_soft_clipped_length $min_quality");

		##HERE: COMBINE OUTPUT FILES TOGETHER

				
		mergeOutputFiles();
		parseOutput();
	}

}

outputFiles();
cleanup();
1;
